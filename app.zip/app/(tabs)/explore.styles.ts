import { Colors } from "@/styles/colors";
import { Spacing } from "@/styles/spacing";
import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  // scrolling correctness
  safe: { flex: 1, backgroundColor: Colors.surface },
  scroll: { flex: 1, backgroundColor: Colors.surface },

  // ✅ avoid double bottom spacing (we’ll keep only one bottom spacer)
  content: {
    flexGrow: 1,
  },

  header: {
    paddingHorizontal: Spacing.lg,
    // paddingTop injected in explore.tsx using safe-area insets
    paddingBottom: Spacing.lg, // ✅ give header a clean bottom rhythm
  },

  headerTopRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
  },

  headerLeft: {
    flex: 1,
    paddingRight: Spacing.md,
  },

  kicker: {
    color: Colors.muted,
    fontSize: 12,
    fontWeight: "700",
    letterSpacing: 0.2,
  },

  title: {
    marginTop: 6,
    color: Colors.text,
    fontSize: 28,
    lineHeight: 32,
    fontWeight: "900",
    letterSpacing: -0.4,
  },

  subtitle: {
    marginTop: 10,
    color: Colors.muted,
    fontSize: 13,
    lineHeight: 18,
    fontWeight: "600",
  },

  cardPressed: { opacity: 0.92 },

  activePill: {
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 999,
    backgroundColor: "rgba(255,255,255,0.92)",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "rgba(0,0,0,0.08)",
  },

  activePillText: {
    color: Colors.text,
    fontSize: 11,
    fontWeight: "900",
    letterSpacing: -0.1,
  },

  // ✅ keep rails tight + consistent
  rails: {
    paddingTop: 0,
  },

  // ✅ reduce between-section gap (this is the main fix)
  rail: {
    paddingTop: Spacing.lg, // was xl
  },

  railHeader: {
    paddingHorizontal: Spacing.lg,
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
    marginBottom: Spacing.sm, // ✅ brings header closer to its content
  },

  railHeaderLeft: {
    flex: 1,
    paddingRight: Spacing.md,
  },

  railTitle: {
    color: Colors.text,
    fontSize: 18,
    lineHeight: 22,
    fontWeight: "900",
    letterSpacing: -0.2,
  },

  railSubtitle: {
    marginTop: 2,
    color: Colors.muted,
    fontSize: 12,
    lineHeight: 16,
    fontWeight: "600",
  },

  railAll: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 6,
    paddingHorizontal: 8,
    borderRadius: 10,
  },

  railAllPressed: { opacity: 0.8 },

  railAllText: {
    color: Colors.muted,
    fontSize: 12,
    fontWeight: "800",
    marginRight: 4,
  },

  // ✅ remove excess vertical padding inside rail list
  railListContent: {
    paddingHorizontal: Spacing.lg,
    paddingTop: 0,          // was md
    paddingBottom: Spacing.sm, // slight breathing room
  },

  // Programs (big tiles)
  programCardWrap: {
    width: 300,
    marginRight: Spacing.md,
  },

  programTile: {
    width: "100%",
    height: 340,
    borderRadius: 28,
    overflow: "hidden",
    backgroundColor: Colors.card,
  },

  programTileImage: {
    ...StyleSheet.absoluteFillObject,
    width: "100%",
    height: "100%",
  },

  programTileFade: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    height: 140,
    backgroundColor: "rgba(0,0,0,0.20)",
  },

  programTileTopRow: {
    position: "absolute",
    top: Spacing.sm,
    left: Spacing.sm,
    right: Spacing.sm,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  programTileBottom: {
    position: "absolute",
    left: Spacing.md,
    right: Spacing.md,
    bottom: Spacing.md,
  },

  programTileTitle: {
    color: Colors.white,
    fontSize: 26,
    lineHeight: 30,
    fontWeight: "900",
    letterSpacing: -0.4,
  },

  programTileMeta: {
    marginTop: 6,
    color: "rgba(255,255,255,0.90)",
    fontSize: 14,
    fontWeight: "700",
  },

  programBelow: {
    paddingTop: 10,
    paddingHorizontal: 2,
  },

  programBelowMeta: {
    color: Colors.muted,
    fontSize: 13,
    fontWeight: "700",
  },

  // Mini cards (workouts/recipes)
  // --- Editorial Card (workouts / recipes) ---
miniCard: {
  width: 300,
  borderRadius: 22,
  overflow: "hidden",
  backgroundColor: Colors.surface,
  borderWidth: StyleSheet.hairlineWidth,
  borderColor: Colors.border,
  marginRight: Spacing.md,
},

miniMedia: {
  height: 150,
  backgroundColor: Colors.card,
},

miniImage: {
  ...StyleSheet.absoluteFillObject,
  width: "100%",
  height: "100%",
},

miniBody: {
  paddingHorizontal: 16,
  paddingTop: 12,
  paddingBottom: 14,
  backgroundColor: Colors.surface,
},

miniTitle: {
  color: Colors.text,
  fontSize: 18,
  lineHeight: 22,
  fontWeight: "900",
  letterSpacing: -0.2,
},

miniMeta: {
  marginTop: 4,
  color: Colors.muted,
  fontSize: 12,
  fontWeight: "600",
},

  // ✅ keep only ONE bottom spacing source
  bottomSpacer: {
    height: Spacing.xl,
  },
});